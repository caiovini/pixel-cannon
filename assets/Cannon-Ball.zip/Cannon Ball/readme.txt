Fruit game graphics by RedFoc, visit http://redfoc.com for more free game asset

You may use these graphics in personal and commercial projects.
Credit (http://redfoc.com) would be nice but is not mandatory.

License (Creative Commons Zero, CC0)
http://creativecommons.org/publicdomain/zero/1.0/